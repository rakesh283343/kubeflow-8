{
 "cells": [],
 "metadata": {
  "environment": {
   "name": "common-cpu.m54",
   "type": "gcloud",
   "uri": "gcr.io/deeplearning-platform-release/base-cpu:m54"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 4
}
